package com.demo.services;

import com.demo.entities.Product;

public interface ProductService {

	public Iterable<Product> findAll();

}
